
#include <Rcpp.h>
#include <R_ext/Utils.h>
#include "typedefs.h"
#include "headers.h"

using namespace Rcpp;

//=============================================================================

// Calculate con and cov of disjunctions
//
//   x   membership scores of antecendens
//   y   membership scores of consequens
// [[Rcpp::export]]
NumericVector C_conCov_ratio(const NumericVector x, const NumericVector y, const IntegerVector f, 
                             const numMatList alpha){
  int n=x.size();
  NumericVector Sums(6), conCov(2);
  for (int i=0; i<n; i++){
    Sums(0)+=std::min(x[i],  y[i]  )*f(i);
    Sums(1)+=std::min(1-x[i],1-y[i])*f(i);
    Sums(2)+=std::min(x[i],  1-y[i])*f(i);
    Sums(3)+=std::min(1-x[i],y[i]  )*f(i);
    Sums(4)+=std::min(std::min(x[i],1-x[i]), std::min(y[i],1-y[i]))*f(i);
    Sums(5)+=f(i);
  };
  numMatList a = C_adaptAlpha(alpha, Sums); // adapted alpha
  conCov(0) = (a[0](0,0)*Sums(0) + a[0](1,0)*Sums(1) + a[0](2,0)*Sums(2) + a[0](3,0)*Sums(3) + a[0](4,0)*Sums(4) + a[0](5,0)*Sums(5)) /
              (a[0](0,1)*Sums(0) + a[0](1,1)*Sums(1) + a[0](2,1)*Sums(2) + a[0](3,1)*Sums(3) + a[0](4,1)*Sums(4) + a[0](5,1)*Sums(5));
  conCov(1) = (a[1](0,0)*Sums(0) + a[1](1,0)*Sums(1) + a[1](2,0)*Sums(2) + a[1](3,0)*Sums(3) + a[1](4,0)*Sums(4) + a[1](5,0)*Sums(5)) /
              (a[1](0,1)*Sums(0) + a[1](1,1)*Sums(1) + a[1](2,1)*Sums(2) + a[1](3,1)*Sums(3) + a[1](4,1)*Sums(4) + a[1](5,1)*Sums(5));
  return(conCov);
}


// Calculate con and cov of disjunctions
//   x   membership scores of antecendens
//   y   membership scores of consequens
// [[Rcpp::export]]
NumericVector C_conCov_harm(const NumericVector x, const NumericVector y, const IntegerVector f, 
                            const NumericVector beta){
  int n=x.size();
  NumericVector Sums(6), conCov(2);
  for (int i=0; i<n; i++){
    Sums(0)+=std::min(x[i],  y[i]  )*f(i);
    Sums(1)+=std::min(1-x[i],1-y[i])*f(i);
    Sums(2)+=std::min(x[i],  1-y[i])*f(i);
    Sums(3)+=std::min(1-x[i],y[i]  )*f(i);
    Sums(4)+=std::min(std::min(x[i],1-x[i]), std::min(y[i],1-y[i]))*f(i);
    Sums(5)+=f(i);
  };
  double 
    con =  Sums(0)/(Sums(0) + Sums(2) - Sums(4)),
    cov =  Sums(0)/(Sums(0) + Sums(3) - Sums(4)),
    spec = Sums(1)/(Sums(1) + Sums(2) - Sums(4)),
    npv =  Sums(1)/(Sums(1) + Sums(3) - Sums(4));
  NumericVector b = C_adaptBeta(beta, Sums); // adapted beta
  conCov(0) = (1 + b(0)*b(0))*con*spec / (b(0)*b(0)*con + spec);
  conCov(1) = (1 + b(1)*b(1))*cov*npv / (b(1)*b(1)*cov + npv);
  return(conCov);
}

// Calculate con and cov of disjunctions
//   x   membership scores of antecendens
//   y   membership scores of consequens
// [[Rcpp::export]]
NumericVector C_conCov_Z(const NumericVector x, const NumericVector y, const IntegerVector f){
  int n=x.size();
  NumericVector Sums(6), conCov(2);
  for (int i=0; i<n; i++){
    Sums(0)+=std::min(x[i],  y[i]  )*f(i);
    Sums(1)+=std::min(1-x[i],1-y[i])*f(i);
    Sums(2)+=std::min(x[i],  1-y[i])*f(i);
    Sums(3)+=std::min(1-x[i],y[i]  )*f(i);
    Sums(4)+=std::min(std::min(x[i],1-x[i]), std::min(y[i],1-y[i]))*f(i);
    Sums(5)+=f(i);
  };
  double 
    SX =  Sums(0) + Sums(2) - Sums(4),
    SY =  Sums(0) + Sums(3) - Sums(4),
    Sx =  Sums(1) + Sums(3) - Sums(4),
    Sy =  Sums(1) + Sums(2) - Sums(4),
    SXy = Sums(2),
    SxY = Sums(3),
    SXxYy = Sums(4),
    N = Sums(5);
  conCov(0) = std::max(0.5, 1 - .5*(SXy - .5*SXxYy)*N / (SX*Sy));
  conCov(1) = std::max(0.5, 1 - .5*(SxY - .5*SXxYy)*N / (Sx*SY));
  return(conCov);
}

// Calculate con and cov of disjunctions
//   x   membership scores of antecendens
//   y   membership scores of consequens
// [[Rcpp::export]]
NumericVector C_conCov_w(const NumericVector x, const NumericVector y, const IntegerVector f, 
                         const NumericVector gamma){
  int n=x.size();
  NumericVector Sums(6), conCov(2);
  for (int i=0; i<n; i++){
    Sums(0)+=std::min(x[i],  y[i]  )*f(i);
    Sums(1)+=std::min(1-x[i],1-y[i])*f(i);
    Sums(2)+=std::min(x[i],  1-y[i])*f(i);
    Sums(3)+=std::min(1-x[i],y[i]  )*f(i);
    Sums(4)+=std::min(std::min(x[i],1-x[i]), std::min(y[i],1-y[i]))*f(i);
    Sums(5)+=f(i);
  };
  double 
    SX = Sums(0)+Sums(2)-Sums(4),
    SY = Sums(0)+Sums(3)-Sums(4),
    Sx = Sums(1)+Sums(3)-Sums(4),
    Sy = Sums(1)+Sums(2)-Sums(4), 
    k = gamma(2);
  double con, cov;
  if (gamma(0) == 0.0){
    con = Sums(0)/(Sums(0) + (SY + k * Sums(4))/(Sy - k * Sums(4)) * (Sums(2) - Sums(4)));
  } else {
    con = Sums(1)/(Sums(1) + (Sx + k * Sums(4))/(SX - k * Sums(4)) * (Sums(2) - Sums(4)));
  }
  if (gamma(1) == 0.0){
    cov = Sums(0)/(Sums(0) + (SX + k * Sums(4))/(Sx - k * Sums(4)) * (Sums(3) - Sums(4)));
  } else {
    cov = Sums(1)/(Sums(1) + (Sy + k * Sums(4))/(SY - k * Sums(4)) * (Sums(3) - Sums(4)));
  }  
  conCov(0) = con;
  conCov(1) = cov;
  return(conCov);
}

//=============================================================================

// C_subsetMin: minimum of a subset of the elements of an integer vector
//   x    vector
//   sub  subset of elements to consider
// [[Rcpp::export]]
double C_subsetMin(const NumericVector x, const IntegerVector sub){
  int len = sub.size();
  double out = x(sub(0)-1);
  if (len == 1) return(out);
  for (int i=1; i<sub.size(); i++){
    out = std::min(x(sub(i)-1), out);
  }
  return(out);
}


// membership scores of a series of conjunctions
//   m   IntegerMatrix, the rows representing the components of the conjunctions
//   x  'scores'-matrix
// [[Rcpp::export]]
NumericMatrix C_conjScore(const NumericMatrix x, const IntegerMatrix m){
  int n=x.nrow(), p=m.nrow();
  NumericMatrix out(n,p);
  for (int i=0; i<n; i++){
    for (int j=0; j<p; j++){
      // Rcpp::Rcout << i << " " << j << " " << C_subsetMin(x(i, _), m(j, _)) << std::endl;
      out(i,j) = C_subsetMin(x(i, _), m(j, _));
    }
  }
  return(out);
}

//==============================================================================

// initialize ii
// [[Rcpp::export]]
IntegerVector C_init_ii(const IntegerVector nn, const LogicalVector st){
  int l=nn.size();
  IntegerVector ini(l);
  ini.fill(0);
  for (int j=0; j<l-1; j++){
    if (st[j]){
      ini[j+1] = ini[j] + 1;
    }
  }
  return(ini);
}

// upper limit of ii
// [[Rcpp::export]]
IntegerVector C_set_lim(const IntegerVector nn, const LogicalVector st){
  int l=nn.size();
  IntegerVector lim(l);
  lim = nn - 1; 
  if (l<=1) return(lim);
  for (int j=l-2; j>=0; j--){
    if (st[j]){
      lim[j] = lim[j+1] - 1;
    }
  }
  return(lim);
}

// C_max_which
// [[Rcpp::export]]
int C_max_which(const LogicalVector x) {
  int n = x.size();
  int i;
  for (i=n-1; i >= 0; i--) {
    if (x[i]) break;
  }
  return(i+1);
}


// increment ii
// [[Rcpp::export]]
IntegerVector C_increment(IntegerVector ii, const IntegerVector nn, 
                          const LogicalVector st, const IntegerVector lim){
  int l = ii.size();
  if (ii[l-1] < lim[l-1]){    // end of loop not yet reached in last position
    ii[l-1] += 1;
    return(ii);
  } 
  // p = first position with increment in index
  int p=C_max_which(ii < lim);
  if (p == 0){
    ii.fill(0);
    return(ii);
  }
  // increment index positions < p
  if (p==1){
    ii[0] += 1; 
  } else {
    ii[Range(0, p-1)] = C_increment(ii[Range(0, p-1)], nn[Range(0, p-1)], st[Range(0, p-2)], lim[Range(0, p-1)]);
  }
  // reset index positions >= p
  for (int j=p; j<l; j++){
    if (st[j-1]){
      ii[j] = ii[j-1] + 1;
    } else {
      ii[j] = 0;
    } 
  }
  return(ii);
}


/*
// [[Rcpp::export]]
int test_increment(IntegerVector nn, LogicalVector st){
  IntegerVector ii=C_init_ii(nn, st);
  IntegerVector lim=C_set_lim(nn, st);
  int count=0;
  do {
    C_increment(ii, nn, st, lim);
    count++;
  } while (as<bool>(any(ii>0)));
  return(count);
} */


/* R
(nn <- rep(2:4, c(2, 1, 3)))
st <- diff(nn) == 0
C_set_lim(nn, st)
C_init_ii(nn, st)

test_increment(c(4L, 4L), T)
test_increment(c(4L, 4L), F)
test_increment(c(3L, 5L, 7L), c(F, F))

get_n <- function(nn){
  choose_args <- unname(unclass(rle(nn)[2:1]))
  prod(do.call(mapply, c(list(choose), choose_args)))
}
mytest <- function(nn){ 
  n <- get_n(nn)
  st <- diff(nn) == 0L
  cat(n, "\n")
  stopifnot(test_increment(nn, st) == n)
}
mytest(c(3L, 5L, 7L))
mytest(c(1L, 2L, 3L, 3L, 4L, 5L, 5L, 5L, 6L, 7L))
mytest(sort(c(1L, 2L, 3L, 3L, 4L, 5L, 5L, 5L, 6L, 7L)))
mytest(sample(c(1L, 2L, 3L, 3L, 4L, 5L, 5L, 5L, 6L, 7L)))

*/

//==============================================================================


// Find asf's of a given structure (=lengths of the conjunctions in the disjunctions)
// [[Rcpp::export]]
IntegerMatrix C_find_asf_ratio(const IntegerVector conjlen, const numMatList x, 
                               const NumericVector y, const IntegerVector f,
                               const double con, const double cov, 
                               const long int maxSol, const numMatList alpha){
  int n_conj = conjlen.size();

  // st = indicator, =true if conj hast same length as precedent conj
  LogicalVector st(n_conj - 1);
  st = (Rcpp::diff(conjlen) == 0);
  
  // nn = number of conjunctions
  IntegerVector nn(n_conj);
  for (int i=0; i<n_conj; i++){
    nn(i)=as<NumericMatrix>(x[i]).ncol();
  }

  // intialize ii, count, out; define lim
  IntegerVector ii=C_init_ii(nn, st);
  long int count=0L;
  IntegerMatrix out(maxSol, n_conj);
  IntegerVector lim=C_set_lim(nn, st);
  
  // Main loop over combinations
  do {
    // Calculate membership Scores for disjunction
    //Rcpp::Rcout << ii << " count=" << count << std::endl;
    NumericVector ms=as<NumericMatrix>(x[0])(_, ii[0]);
    //Rcpp::Rcout << /*"min: " << minim << ", */ "max: " << ms << std::endl;
    for (int i=1; i<n_conj; i++){
      ms=pmax(ms, as<NumericMatrix>(x[i])(_, ii[i]));
      //Rcpp::Rcout << /*"min: " << minim << ", */ "max: " << ms << std::endl;
    }
    // calculate con und cov
    NumericVector coco=C_conCov_ratio(ms, y, f, alpha);
    //Rcpp::Rcout << "coco: " << coco << std::endl;
    
    // Conditionally insert in next row of the matrix
    if (coco(0) >= con && coco(1) >= cov){      // con and cov values >= thresholds
      for (int j=0; j<n_conj; j++){
        out(count, j) = ii[j];
      }
      count++;
    }

    // increment:
    C_increment(ii, nn, st, lim);
    
    if (count>=maxSol){
      Rcpp::Rcout << "Not all candidate solutions are recorded (maxSol="<< maxSol << ")" 
                  << std::endl;
      break;
    }
    if (count % 1000000L == 0L)	R_CheckUserInterrupt();
  } while (as<bool>(any(ii>0)));
  
  // if (count > 0){
  //   Rcpp::Rcout << "count="<< count << std::endl;
  // }
  
  // Return matrix with 0 rows if count=0:
  if (count == 0L){ 
    IntegerMatrix a(0, n_conj);
    return a;
  }
  
  // Return result matrix
  return out(Range(0, count-1L), _);
}




// Find asf's of a given structure (=lengths of the conjunctions in the disjunctions)  -- case "ccDef_harm"
// [[Rcpp::export]]
IntegerMatrix C_find_asf_harm(const IntegerVector conjlen, const numMatList x, 
                              const NumericVector y, const IntegerVector f,
                              const double con, const double cov, 
                              const long int maxSol, const NumericVector beta){
  int n_conj = conjlen.size();

  // st = indicator, =true if conj hast same length as precedent conj
  LogicalVector st(n_conj - 1);
  st = (Rcpp::diff(conjlen) == 0);
  
  // nn = number of conjunctions
  IntegerVector nn(n_conj);
  for (int i=0; i<n_conj; i++){
    nn(i)=as<NumericMatrix>(x[i]).ncol();
  }

  // intialize ii, count, out; define lim
  IntegerVector ii=C_init_ii(nn, st);
  long int count=0L;
  IntegerMatrix out(maxSol, n_conj);
  IntegerVector lim=C_set_lim(nn, st);
  
  // Main loop over combinations
  do {
    // Calculate membership Scores for disjunction
    //Rcpp::Rcout << ii << " count=" << count << std::endl;
    NumericVector ms=as<NumericMatrix>(x[0])(_, ii[0]);
    //Rcpp::Rcout << /*"min: " << minim << ", */ "max: " << ms << std::endl;
    for (int i=1; i<n_conj; i++){
      ms=pmax(ms, as<NumericMatrix>(x[i])(_, ii[i]));
      //Rcpp::Rcout << /*"min: " << minim << ", */ "max: " << ms << std::endl;
    }
    // calculate con und cov
    NumericVector coco=C_conCov_harm(ms, y, f, beta);
    //Rcpp::Rcout << "coco: " << coco << std::endl;
    
    // Conditionally insert in next row of the matrix
    if (coco(0) >= con && coco(1) >= cov){      // con and cov values >= thresholds
      for (int j=0; j<n_conj; j++){
        out(count, j) = ii[j];
      }
      count++;
    }

    // increment:
    C_increment(ii, nn, st, lim);
    
    if (count>=maxSol){
      Rcpp::Rcout << "Not all candidate solutions are recorded (maxSol="<< maxSol << ")" 
                  << std::endl;
      break;
    }
    if (count % 1000000L == 0L)	R_CheckUserInterrupt();
  } while (as<bool>(any(ii>0)));
  
  // if (count > 0){
  //   Rcpp::Rcout << "count="<< count << std::endl;
  // }
  
  // Return matrix with 0 rows if count=0:
  if (count == 0L){ 
    IntegerMatrix a(0, n_conj);
    return a;
  }
  
  // Return result matrix
  return out(Range(0, count-1L), _);
}

// Find asf's of a given structure (=lengths of the conjunctions in the disjunctions)  -- case "ccDef_Z"
// [[Rcpp::export]]
IntegerMatrix C_find_asf_Z(const IntegerVector conjlen, const numMatList x, 
                           const NumericVector y, const IntegerVector f,
                           const double con, const double cov, 
                           const long int maxSol){
  int n_conj = conjlen.size();

  // st = indicator, =true if conj hast same length as precedent conj
  LogicalVector st(n_conj - 1);
  st = (Rcpp::diff(conjlen) == 0);
  
  // nn = number of conjunctions
  IntegerVector nn(n_conj);
  for (int i=0; i<n_conj; i++){
    nn(i)=as<NumericMatrix>(x[i]).ncol();
  }

  // intialize ii, count, out; define lim
  IntegerVector ii=C_init_ii(nn, st);
  long int count=0L;
  IntegerMatrix out(maxSol, n_conj);
  IntegerVector lim=C_set_lim(nn, st);
  
  // Main loop over combinations
  do {
    // Calculate membership Scores for disjunction
    //Rcpp::Rcout << ii << " count=" << count << std::endl;
    NumericVector ms=as<NumericMatrix>(x[0])(_, ii[0]);
    //Rcpp::Rcout << /*"min: " << minim << ", */ "max: " << ms << std::endl;
    for (int i=1; i<n_conj; i++){
      ms=pmax(ms, as<NumericMatrix>(x[i])(_, ii[i]));
      //Rcpp::Rcout << /*"min: " << minim << ", */ "max: " << ms << std::endl;
    }
    // calculate con und cov
    NumericVector coco=C_conCov_Z(ms, y, f);
    //Rcpp::Rcout << "coco: " << coco << std::endl;
    
    // Conditionally insert in next row of the matrix
    if (coco(0) >= con && coco(1) >= cov){      // con and cov values >= thresholds
      for (int j=0; j<n_conj; j++){
        out(count, j) = ii[j];
      }
      count++;
    }

    // increment:
    C_increment(ii, nn, st, lim);
    
    if (count>=maxSol){
      Rcpp::Rcout << "Not all candidate solutions are recorded (maxSol="<< maxSol << ")" 
                  << std::endl;
      break;
    }
    if (count % 1000000L == 0L)	R_CheckUserInterrupt();
  } while (as<bool>(any(ii>0)));
  
  // if (count > 0){
  //   Rcpp::Rcout << "count="<< count << std::endl;
  // }
  
  // Return matrix with 0 rows if count=0:
  if (count == 0L){ 
    IntegerMatrix a(0, n_conj);
    return a;
  }
  
  // Return result matrix
  return out(Range(0, count-1L), _);
}

// Find asf's of a given structure (=lengths of the conjunctions in the disjunctions)  -- case "ccDef_harm"
// [[Rcpp::export]]
IntegerMatrix C_find_asf_w(const IntegerVector conjlen, const numMatList x, 
                           const NumericVector y, const IntegerVector f,
                           const double con, const double cov, 
                           const long int maxSol, const NumericVector gamma){
  int n_conj = conjlen.size();

  // st = indicator, =true if conj hast same length as precedent conj
  LogicalVector st(n_conj - 1);
  st = (Rcpp::diff(conjlen) == 0);
  
  // nn = number of conjunctions
  IntegerVector nn(n_conj);
  for (int i=0; i<n_conj; i++){
    nn(i)=as<NumericMatrix>(x[i]).ncol();
  }

  // intialize ii, count, out; define lim
  IntegerVector ii=C_init_ii(nn, st);
  long int count=0L;
  IntegerMatrix out(maxSol, n_conj);
  IntegerVector lim=C_set_lim(nn, st);
  
  // Main loop over combinations
  do {
    // Calculate membership Scores for disjunction
    //Rcpp::Rcout << ii << " count=" << count << std::endl;
    NumericVector ms=as<NumericMatrix>(x[0])(_, ii[0]);
    //Rcpp::Rcout << /*"min: " << minim << ", */ "max: " << ms << std::endl;
    for (int i=1; i<n_conj; i++){
      ms=pmax(ms, as<NumericMatrix>(x[i])(_, ii[i]));
      //Rcpp::Rcout << /*"min: " << minim << ", */ "max: " << ms << std::endl;
    }
    // calculate con und cov
    NumericVector coco=C_conCov_w(ms, y, f, gamma);
    //Rcpp::Rcout << "coco: " << coco << std::endl;
    
    // Conditionally insert in next row of the matrix
    if (coco(0) >= con && coco(1) >= cov){      // con and cov values >= thresholds
      for (int j=0; j<n_conj; j++){
        out(count, j) = ii[j];
      }
      count++;
    }

    // increment:
    C_increment(ii, nn, st, lim);
    
    if (count>=maxSol){
      Rcpp::Rcout << "Not all candidate solutions are recorded (maxSol="<< maxSol << ")" 
                  << std::endl;
      break;
    }
    if (count % 1000000L == 0L)	R_CheckUserInterrupt();
  } while (as<bool>(any(ii>0)));
  
  // if (count > 0){
  //   Rcpp::Rcout << "count="<< count << std::endl;
  // }
  
  // Return matrix with 0 rows if count=0:
  if (count == 0L){ 
    IntegerMatrix a(0, n_conj);
    return a;
  }
  
  // Return result matrix
  return out(Range(0, count-1L), _);
}

