
#include <Rcpp.h>
using namespace Rcpp;
#include "typedefs.h"


// Adapt alpha (experimental)
// [[Rcpp::export]]
numMatList C_adaptAlpha(const numMatList a, const NumericVector s){
  numMatList out = clone(Rcpp::List::create(a[0], a[1]));
  for (int i=0; i<2; i++){
    for (int j=0; j<a[1].nrow(); j++){
      for (int k=0; k<a[1].ncol(); k++){
        if (out[i](j,k) == -99){
          out[i](j,k) = pow( (s(1)+s(2)-s(4)) / (s(0)+s(3)-s(4)), a[i+2](j,k));  // y/Y
          if (j == 4) out[i](j,k) = -out[i](j,k);
        }
        if (out[i](j,k) == -98){
          out[i](j,k) = pow( (s(1)+s(3)-s(4)) / (s(0)+s(2)-s(4)), a[i+2](j,k));  // x/X
          if (j == 4) out[i](j,k) = -out[i](j,k);
        }   
        if (out[i](j,k) == -97){
          out[i](j,k) = pow( (s(1)+s(3)-s(4)) / (s(0)+s(3)-s(4)), a[i+2](j,k));  // x/Y
          if (j == 4) out[i](j,k) = -out[i](j,k);
        }   
        if (out[i](j,k) == -96){
          out[i](j,k) = pow( (s(1)+s(2)-s(4)) / (s(0)+s(2)-s(4)), a[i+2](j,k));  // y/X
          if (j == 4) out[i](j,k) = -out[i](j,k);
        }   
        if (out[i](j,k) == -95){
          out[i](j,k) = pow(s(0)+s(2)-s(4), a[i+2](j,k)); // X
          if (j == 4) out[i](j,k) = -out[i](j,k);
        }   
        if (out[i](j,k) == -94){
          out[i](j,k) = pow(s(0)+s(3)-s(4), a[i+2](j,k)); // Y
          if (j == 4) out[i](j,k) = -out[i](j,k);
        }   
        if (out[i](j,k) == -93){
          out[i](j,k) = pow(s(1)+s(3)-s(4), a[i+2](j,k)); // x
          if (j == 4) out[i](j,k) = -out[i](j,k);
        }   
        if (out[i](j,k) == -92){
          out[i](j,k) = pow(s(1)+s(2)-s(4), a[i+2](j,k)); // y
          if (j == 4) out[i](j,k) = -out[i](j,k);
        }
      }
    }
  }
  return(out);
}

// Adapt beta (experimental)
// [[Rcpp::export]]
NumericVector C_adaptBeta(const NumericVector b, const NumericVector s){
  NumericVector out = b[Range(0, 1)];
  for (int i=0; i<2; i++){
    if (out(i) == -99){
      out(i) = pow( (s(1)+s(2)-s(4)) / (s(0)+s(3)-s(4)), b(i+2));  // y/Y
    }
    if (out(i) == -98){
      out(i) = pow( (s(1)+s(3)-s(4)) / (s(0)+s(2)-s(4)), b(i+2));  // x/X
    }   
    if (out(i) == -97){
      out(i) = pow( (s(1)+s(3)-s(4)) / (s(0)+s(3)-s(4)), b(i+2));  // x/Y
    }   
    if (out(i) == -96){
      out(i) = pow( (s(1)+s(2)-s(4)) / (s(0)+s(2)-s(4)), b(i+2));  // y/X
    }   
    if (out(i) == -95){
      out(i) = pow(s(0)+s(2)-s(4), b(i+2)); // X
    }   
    if (out(i) == -94){
      out(i) = pow(s(0)+s(3)-s(4), b(i+2)); // Y
    }   
    if (out(i) == -93){
      out(i) = pow(s(1)+s(3)-s(4), b(i+2)); // x
    }   
    if (out(i) == -92){
      out(i) = pow(s(1)+s(2)-s(4), b(i+2)); // y
    }
  }
  return(out);
}


// Calculate con and cov of conjunctions
// [[Rcpp::export]]
NumericVector C_conj_conCov_ratio(const IntegerVector cols, const NumericMatrix x, 
                                  const NumericVector y, const IntegerVector f, 
                                  const numMatList alpha){
  int n=x.nrow(), p=cols.size();
  NumericVector Sums(6), conCov(2);
  for (int i=0; i<n; i++){
    double minX=1;
    for (int j=0; j<p; j++){
      double Xval=x(i, cols[j]-1);
      if (Xval<minX) minX=Xval;
    };
    double Yval=y[i];
    Sums(0)+=std::min(minX,  Yval  )*f(i);
    Sums(1)+=std::min(1-minX,1-Yval)*f(i);
    Sums(2)+=std::min(minX,  1-Yval)*f(i);
    Sums(3)+=std::min(1-minX,Yval  )*f(i);
    Sums(4)+=std::min(std::min(minX,1-minX), std::min(Yval,1-Yval))*f(i);
    Sums(5)+=f(i);
  };
  numMatList a = C_adaptAlpha(alpha, Sums); // adapted alpha
  conCov(0) = (a[0](0,0)*Sums(0) + a[0](1,0)*Sums(1) + a[0](2,0)*Sums(2) + a[0](3,0)*Sums(3) + a[0](4,0)*Sums(4) + a[0](5,0)*Sums(5)) /
              (a[0](0,1)*Sums(0) + a[0](1,1)*Sums(1) + a[0](2,1)*Sums(2) + a[0](3,1)*Sums(3) + a[0](4,1)*Sums(4) + a[0](5,1)*Sums(5));
  conCov(1) = (a[1](0,0)*Sums(0) + a[1](1,0)*Sums(1) + a[1](2,0)*Sums(2) + a[1](3,0)*Sums(3) + a[1](4,0)*Sums(4) + a[1](5,0)*Sums(5)) /
              (a[1](0,1)*Sums(0) + a[1](1,1)*Sums(1) + a[1](2,1)*Sums(2) + a[1](3,1)*Sums(3) + a[1](4,1)*Sums(4) + a[1](5,1)*Sums(5));
  return conCov;
}

// Calculate con and cov of conjunctions -- case "ccDef_harm"
// [[Rcpp::export]]
NumericVector C_conj_conCov_harm(const IntegerVector cols, const NumericMatrix x, 
                                 const NumericVector y, const IntegerVector f, 
                                 const NumericVector beta){
  int n=x.nrow(), p=cols.size();
  NumericVector Sums(6), conCov(2);
  for (int i=0; i<n; i++){
    double minX=1;
    for (int j=0; j<p; j++){
      double Xval=x(i, cols[j]-1);
      if (Xval<minX) minX=Xval;
    };
    double Yval=y[i];
    Sums(0)+=std::min(minX,  Yval  )*f(i);
    Sums(1)+=std::min(1-minX,1-Yval)*f(i);
    Sums(2)+=std::min(minX,  1-Yval)*f(i);
    Sums(3)+=std::min(1-minX,Yval  )*f(i);
    Sums(4)+=std::min(std::min(minX,1-minX), std::min(Yval,1-Yval))*f(i);
    Sums(5)+=f(i);
  };
  double 
    con =  Sums(0)/(Sums(0) + Sums(2) - Sums(4)),
    cov =  Sums(0)/(Sums(0) + Sums(3) - Sums(4)),
    spec = Sums(1)/(Sums(1) + Sums(2) - Sums(4)),
    npv =  Sums(1)/(Sums(1) + Sums(3) - Sums(4));
  NumericVector b = C_adaptBeta(beta, Sums); // adapted beta
  conCov(0) = (1 + b(0)*b(0))*con*spec / (b(0)*b(0)*con + spec);
  conCov(1) = (1 + b(1)*b(1))*cov*npv / (b(1)*b(1)*cov + npv);
  return conCov;
}

// Calculate con and cov of conjunctions -- case "ccDef_Z"
// [[Rcpp::export]]
NumericVector C_conj_conCov_Z(const IntegerVector cols, const NumericMatrix x, 
                              const NumericVector y, const IntegerVector f){
  int n=x.nrow(), p=cols.size();
  NumericVector Sums(6), conCov(2);
  for (int i=0; i<n; i++){
    double minX=1;
    for (int j=0; j<p; j++){
      double Xval=x(i, cols[j]-1);
      if (Xval<minX) minX=Xval;
    };
    double Yval=y[i];
    Sums(0)+=std::min(minX,  Yval  )*f(i); // SXY
    Sums(1)+=std::min(1-minX,1-Yval)*f(i); // Sxy
    Sums(2)+=std::min(minX,  1-Yval)*f(i); // SXy
    Sums(3)+=std::min(1-minX,Yval  )*f(i); // SxY
    Sums(4)+=std::min(std::min(minX,1-minX), std::min(Yval,1-Yval))*f(i);      // SXxYy
    Sums(5)+=f(i);                         // N
  };
  double 
    SX =  Sums(0) + Sums(2) - Sums(4),
    SY =  Sums(0) + Sums(3) - Sums(4),
    Sx =  Sums(1) + Sums(3) - Sums(4),
    Sy =  Sums(1) + Sums(2) - Sums(4),
    SXy = Sums(2),
    SxY = Sums(3),
    SXxYy = Sums(4),
    N = Sums(5);
  conCov(0) = std::max(0.5, 1 - .5*(SXy - .5*SXxYy)*N / (SX*Sy));
  conCov(1) = std::max(0.5, 1 - .5*(SxY - .5*SXxYy)*N / (Sx*SY));
  return conCov;
}

// Calculate con and cov of conjunctions -- case "ccDef_w"
// [[Rcpp::export]]
NumericVector C_conj_conCov_w(const IntegerVector cols, const NumericMatrix x, 
                              const NumericVector y, const IntegerVector f, 
                              const NumericVector gamma){
  int n=x.nrow(), p=cols.size();
  NumericVector Sums(6), conCov(2);
  for (int i=0; i<n; i++){
    double minX=1;
    for (int j=0; j<p; j++){
      double Xval=x(i, cols[j]-1);
      if (Xval<minX) minX=Xval;
    };
    double Yval=y[i];
    Sums(0)+=std::min(minX,  Yval  )*f(i);
    Sums(1)+=std::min(1-minX,1-Yval)*f(i);
    Sums(2)+=std::min(minX,  1-Yval)*f(i);
    Sums(3)+=std::min(1-minX,Yval  )*f(i);
    Sums(4)+=std::min(std::min(minX,1-minX), std::min(Yval,1-Yval))*f(i);
    Sums(5)+=f(i);
  };
  double 
    SX = Sums(0)+Sums(2)-Sums(4),
    SY = Sums(0)+Sums(3)-Sums(4),
    Sx = Sums(1)+Sums(3)-Sums(4),
    Sy = Sums(1)+Sums(2)-Sums(4), 
    k = gamma(2);
  double con, cov;
  if (gamma(0) == 0.0){
    con = Sums(0)/(Sums(0) + (SY + k * Sums(4))/(Sy - k * Sums(4)) * (Sums(2) - Sums(4)));
  } else {
    con = Sums(1)/(Sums(1) + (Sx + k * Sums(4))/(SX - k * Sums(4)) * (Sums(2) - Sums(4)));
  }
  if (gamma(1) == 0.0){
    cov = Sums(0)/(Sums(0) + (SX + k * Sums(4))/(Sx - k * Sums(4)) * (Sums(3) - Sums(4)));
  } else {
    cov = Sums(1)/(Sums(1) + (Sy + k * Sums(4))/(SY - k * Sums(4)) * (Sums(3) - Sums(4)));
  }  
  conCov(0) = con;
  conCov(1) = cov;
  return conCov;
}


// Calculate con and cov of disjunctions
// [[Rcpp::export]]
NumericVector C_disj_conCov(const IntegerVector cols, const NumericMatrix x, 
                            const NumericVector y, const IntegerVector f){
  int n=x.nrow(), p=cols.size();
  NumericVector Sums(3), conCov(2);
  for (int i=0; i<n; i++){
    double maxX=0;
    for (int j=0; j<p; j++){
      double Xval=x(i, cols[j]-1);
      if (Xval>maxX) maxX=Xval;
    };
    double Yval=y[i];
    double XY=std::min(maxX,Yval);
    Sums(0)+=maxX*f(i);
    Sums(1)+=Yval*f(i);
    Sums(2)+=XY*f(i);
  };
  conCov(0) = Sums(2)/Sums(0);
  conCov(1) = Sums(2)/Sums(1);
  return conCov;
}

/* R
set.seed(1234)
x <- matrix(runif(20), 4)
cols <- c(2, 4)
y <- runif(nrow(x))
f1 <- rep(1L, length(y))
f <- seq_along(x)
x
y
f
extractColumns(x, cols)
M(x, cols)
M2(x, cols, y)
C_conj_conCov_ratio(x, cols, y, f)

*/
