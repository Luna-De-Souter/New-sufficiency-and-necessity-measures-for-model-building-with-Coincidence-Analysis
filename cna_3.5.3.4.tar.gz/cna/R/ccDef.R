
nms1 <- c("SXY", "Sxy", "SXy", "SxY", "SXYxy", "n")
nms2 <- c("(Sy/SY)", "(Sx/SX)", "(Sx/SY)", "(Sy/SX)", "SX", "SY", "Sx", "Sy")

# Generator functions for classes "ccDef_ratio" and "ccDef_harm"
ccDef_ratio <- function(param = list(cbind(c(1, 0, 0, 0, 0, 0), c(1, 0, 1, 0, -1, 0)), 
                                     cbind(c(1, 0, 0, 0, 0, 0), c(1, 0, 0, 1, -1, 0)))
                        ){
  stopifnot(is.list(param), length(param) == 2,
            sapply(param, is.numeric) | sapply(param, is.complex),
            vapply(param, nrow, integer(1)) == 6,
            vapply(param, ncol, integer(1)) == 2)
  names(param) <- c("con", "cov")
  dimnames(param[[1]]) <- list(nms1, c("num", "denom"))
  dimnames(param[[2]]) <- list(nms1, c("num", "denom"))
  class(param) <- c("ccDef_ratio", "ccDef", "list")
  param
}

ccDef_harm <- function(beta = c(0, 0)){
  stopifnot(is.numeric(beta) | is.complex(beta), length(beta) == 2)
  class(beta) <- c("ccDef_harm", "ccDef", "list")
  beta
}

# ------------------------------------------------------------------------------

# Two new generics are introduced: ccDefReshape() and ccDef2conCov()
ccDefReshape <- function(param, ...) UseMethod("ccDefReshape")

ccDef2conCov <- function(param, ...) UseMethod("ccDef2conCov")

# ------------------------------------------------------------------------------

# Methods for class "ccDef_ratio":
ccDefReshape.ccDef_ratio <- function(param, ...){
  param <- list(Re(param[[1]]), Re(param[[2]]), Im(param[[1]]), Im(param[[2]]))
  param[[3]][param[[3]] == 0] <- 1
  param[[4]][param[[4]] == 0] <- 1
  class(param) <- c("ccDef_ratio_reshaped", "ccDef")
  param
}

ccDef2conCov.ccDef_ratio_reshaped <- function(param, sums, ...){  
  alpha <- unclass(param)
  ncond <- ncol(sums)
  # expand alpha
  alpha[[1]] <- array(rep(alpha[[1]], ncond), c(6, 2, ncond))
  alpha[[2]] <- array(rep(alpha[[2]], ncond), c(6, 2, ncond))
  alpha[[3]] <- array(rep(alpha[[3]], ncond), c(6, 2, ncond))
  alpha[[4]] <- array(rep(alpha[[4]], ncond), c(6, 2, ncond))
  # preselection of positions to be modified:
  sel0 <- list(alpha[[1]] %in% -99:-92, alpha[[2]] %in% -99:-92)
  if (any(sel0[[1]]) || any(sel0[[2]])){
    # calculate ratios
    SX <- sums[1, ]+sums[3, ]-sums[5, ]
    SY <- sums[1, ]+sums[4, ]-sums[5, ]
    Sx <- sums[2, ]+sums[4, ]-sums[5, ]
    Sy <- sums[2, ]+sums[3, ]-sums[5, ]
    for (j in 1:2){
      if (any(sel <- sel0[[j]] & alpha[[j]] == -99)){
        alpha[[j]][sel] <- rep((Sy/SY), each = sum(sel)/ncond)^(alpha[[j+2]][sel])
        alpha[[j]] <- pos5neg(alpha[[j]], sel)
        sel0[[j]][sel] <- FALSE  # excludes later adjustments
        if (!any(sel0[[j]])) next
      }
      if (any(sel <- sel0[[j]] & alpha[[j]] == -98)){
        alpha[[j]][sel] <- rep((Sx/SX), each = sum(sel)/ncond)^(alpha[[j+2]][sel])
        alpha[[j]] <- pos5neg(alpha[[j]], sel)
        sel0[[j]][sel] <- FALSE
        if (!any(sel0[[j]])) next
      }
      if (any(sel <- sel0[[j]] & alpha[[j]] == -97)){
        alpha[[j]][sel] <- rep((Sx/SY), each = sum(sel)/ncond)^(alpha[[j+2]][sel])
        alpha[[j]] <- pos5neg(alpha[[j]], sel)
        sel0[[j]][sel] <- FALSE
        if (!any(sel0[[j]])) next
      }
      if (any(sel <- sel0[[j]] & alpha[[j]] == -96)){
        alpha[[j]][sel] <- rep((Sy/SX), each = sum(sel)/ncond)^(alpha[[j+2]][sel])
        alpha[[j]] <- pos5neg(alpha[[j]], sel)
        sel0[[j]][sel] <- FALSE
        if (!any(sel0[[j]])) next
      }
      if (any(sel <- sel0[[j]] & alpha[[j]] == -95)){
        alpha[[j]][sel] <- rep(SX, each = sum(sel)/ncond)^(alpha[[j+2]][sel])
        alpha[[j]] <- pos5neg(alpha[[j]], sel)
        sel0[[j]][sel] <- FALSE
        if (!any(sel0[[j]])) next
      }
      if (any(sel <- sel0[[j]] & alpha[[j]] == -94)){
        alpha[[j]][sel] <- rep(SY, each = sum(sel)/ncond)^(alpha[[j+2]][sel])
        alpha[[j]] <- pos5neg(alpha[[j]], sel)
        sel0[[j]][sel] <- FALSE
        if (!any(sel0[[j]])) next
      }
      if (any(sel <- sel0[[j]] & alpha[[j]] == -93)){
        alpha[[j]][sel] <- rep(Sx, each = sum(sel)/ncond)^(alpha[[j+2]][sel])
        alpha[[j]] <- pos5neg(alpha[[j]], sel)
        sel0[[j]][sel] <- FALSE
        if (!any(sel0[[j]])) next
      }
      if (any(sel <- sel0[[j]] & alpha[[j]] == -92)){
        alpha[[j]][sel] <- rep(Sy, each = sum(sel)/ncond)^(alpha[[j+2]][sel])
        alpha[[j]] <- pos5neg(alpha[[j]], sel)
        sel0[[j]][sel] <- FALSE
      }
    }
  }
  list(
    consistency = colSums(alpha[[1]][, 1, ] * sums) / colSums(alpha[[1]][, 2, ] * sums),
    coverage = colSums(alpha[[2]][, 1, ] * sums) / colSums(alpha[[2]][, 2, ] * sums))
}

# aux fn reverting sign at position 5
pos5neg <- function(arr, sel){
  if (any(sel5 <- sel & (seq_along(sel)-1) %% 6 == 4))
    arr[sel5] <- -arr[sel5]
  arr  
}

# is this methods required at all??
ccDef2conCov.ccDef_ratio <- function(param, sums, ...){
  ccDef2conCov(ccDefReshape(param), sums, ...)
}

# ------------------------------------------------------------------------------

ccDefReshape.ccDef_harm <- function(param, ...){
  param <- c(Re(param), Im(param))
  param[3:4][param[3:4] == 0] <- 1
  class(param) <- c("ccDef_harm_reshaped", "ccDef")
  param
}

ccDef2conCov.ccDef_harm_reshaped <- function(param, sums, ...){  
  beta <- unclass(param)
  ncond <- ncol(sums)
  # expand beta
  beta_expanded <- data.frame(beta1 = rep(beta[[1]], ncond), 
                              beta2 = rep(beta[[2]], ncond))
  # calculate sums and measures
  SX <- sums[1, ]+sums[3, ]-sums[5, ]
  SY <- sums[1, ]+sums[4, ]-sums[5, ]
  Sx <- sums[2, ]+sums[4, ]-sums[5, ]
  Sy <- sums[2, ]+sums[3, ]-sums[5, ]
  measures <- data.frame(
    con = sums[1, ]/SX,
    cov = sums[1, ]/SY,
    spec = sums[2, ]/Sy,
    npv = sums[2, ]/Sx)
  if (any(beta[1:2] %in% -99:-92)){
    # adjust beta
    for (j in 1:2){
      if (beta[j] == -99){
        beta_expanded[[j]] <- (Sy/SY)^beta[j+2]
        next
      }
      if (beta[j] == -98){
        beta_expanded[[j]] <- (Sx/SX)^beta[j+2]
        next
      }
      if (beta[j] == -97){
        beta_expanded[[j]] <- (Sx/SY)^beta[j+2]
        next
      }
      if (beta[j] == -96){
        beta_expanded[[j]] <- (Sy/SX)^beta[j+2]
        next
        }
      if (beta[j] == -95){
        beta_expanded[[j]] <- SX^beta[j+2]
        next
        }
      if (beta[j] == -94){
        beta_expanded[[j]] <- SY^beta[j+2]
        next
        }
      if (beta[j] == -93){
        beta_expanded[[j]] <- Sx^beta[j+2]
        next
        }
      if (beta[j] == -92){
        beta_expanded[[j]] <- Sy^beta[j+2]
        }
    }
  }
  with(c(beta_expanded, measures), 
       list(consistency = (1 + beta1^2)*con*spec / (beta1^2*con + spec),
            coverage = (1 + beta2^2)*cov*npv / (beta2^2*cov + npv)))
}

# is this methods required at all??
ccDef2conCov.ccDef_harm <- function(param, sums, ...){ 
  ccDef2conCov(ccDefReshape(param), sums, ...)
}
  
# ------------------------------------------------------------------------------

ccDef_Z <- function(x) structure(list(), 
                                 class = c("ccDef_Z", "ccDef"))

ccDefReshape.ccDef <- function(param, ...) param

ccDef2conCov.ccDef_Z <- function(param, sums, ...){
  SX <- sums[1, ]+sums[3, ]-sums[5, ]
  SY <- sums[1, ]+sums[4, ]-sums[5, ]
  Sx <- sums[2, ]+sums[4, ]-sums[5, ]
  Sy <- sums[2, ]+sums[3, ]-sums[5, ]
  SXy <- sums[3, ]
  SxY <- sums[4, ]
  SXxYy <- sums[5, ]
  N <- sums[6, ]
  list(consistency = pmax(.5, 1 - .5*(SXy - .5*SXxYy)*N / (SX*Sy)),
        coverage =   pmax(.5, 1 - .5*(SxY - .5*SXxYy)*N / (Sx*SY)))
}

# ------------------------------------------------------------------------------

ccDef_w <- function(gamma = c(0, 0, 1)){
  stopifnot(is.numeric(gamma), length(gamma) == 3, gamma[1:2] %in% 0:1, 
            gamma[[3]] >= 0, gamma[[3]] <= 1)
  class(gamma) <- c("ccDef_w", "ccDef", "list")
  gamma
}

ccDef2conCov.ccDef_w <- function(param, sums, ...){
  SX <- sums[1, ]+sums[3, ]-sums[5, ]
  SY <- sums[1, ]+sums[4, ]-sums[5, ]
  Sx <- sums[2, ]+sums[4, ]-sums[5, ]
  Sy <- sums[2, ]+sums[3, ]-sums[5, ]
  SXY <- sums[1, ]
  Sxy <- sums[2, ]
  SXy <- sums[3, ]
  SxY <- sums[4, ]
  SXxYy <- sums[5, ]
  N <- sums[6, ]
  .con <- if (param[[1]] == 0){
    SXY/(SXY + (SY + param[3] * SXxYy)/(Sy - param[3] * SXxYy) * (SXy - SXxYy))
  } else {
    Sxy/(Sxy + (Sx + param[3] * SXxYy)/(SX - param[3] * SXxYy) * (SXy - SXxYy))
  }
  .cov <- if (param[[2]] == 0){
    SXY/(SXY + (SX + param[3] * SXxYy)/(Sx - param[3] * SXxYy) * (SxY - SXxYy))
  } else {
    Sxy/(Sxy + (Sy + param[3] * SXxYy)/(SY - param[3] * SXxYy) * (SxY - SXxYy))
  }
  list(consistency = .con, coverage = .cov)
}

