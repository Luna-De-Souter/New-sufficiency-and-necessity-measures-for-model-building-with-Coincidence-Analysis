
# Function deprecated from 3.0.0
truthTab <- function(...){
  .Deprecated("configTable", package = "cna")
  configTable(...)
}
cstt <- function(...){
  .Deprecated("csct", package = "cna")
  csct(...)
}
fstt <- function(...){
  .Deprecated("fsct", package = "cna")
  fsct(...)
}
mvtt <- function(...){
  .Deprecated("mvct", package = "cna")
  mvct(...)
}


full.tt <- function(...){
  .Deprecated("full.ct", package = "cna")
  full.ct(...)
}
tt2df <- function(...){
  .Deprecated("ct2df", package = "cna")
  ct2df(...)
}

